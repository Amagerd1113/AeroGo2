// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef GAZEBO_MSGS__SRV__BODY_REQUEST_HPP_
#define GAZEBO_MSGS__SRV__BODY_REQUEST_HPP_

#include "gazebo_msgs/srv/detail/body_request__struct.hpp"
#include "gazebo_msgs/srv/detail/body_request__builder.hpp"
#include "gazebo_msgs/srv/detail/body_request__traits.hpp"
#include "gazebo_msgs/srv/detail/body_request__type_support.hpp"

#endif  // GAZEBO_MSGS__SRV__BODY_REQUEST_HPP_
